package com.v2dev.customedittextdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.v_sQr_dev.customvalidatoredittext.CustomEdittext;

public class MainActivity extends AppCompatActivity {

    private LinearLayout llContainer;
    private Button btnValidate;
    private CustomEdittext inputPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        llContainer = (LinearLayout) findViewById(R.id.llContainer);
        btnValidate = (Button) findViewById(R.id.btnValidate);
        inputPwd = new CustomEdittext(llContainer, this);
        inputPwd.setHint("PASSWORD");

        btnValidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(inputPwd.validate()){
                    Toast.makeText(MainActivity.this,"Input Valid",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
